library(tidyverse)
library(lubridate)
# loading daily data
daily_data=read_csv("C:\\Users\\sasuk\\OneDrive\\Desktop\\DataAnalyticsCourse\\Project\\Fitbase_Data_Modified\\Daily_data_Merged\\daily_data_merged.csv")

# filtering out data where totalsteps==0, becuase that means the watch wasn't 
# worn by the user that day, this removes roughly 9% of data from the dataset.
temp=daily_data %>% 
  filter(TotalSteps!=0)

# Total steps
qplot(y=temp$TotalSteps,x="",geom='boxplot',fill=I('blue'),ylab='Total Steps',main='Steps Skewness')

# Total distance
qplot(y=temp$TotalDistance,x="",geom='boxplot',fill=I('red'),ylab='Total Distance',main='Distance Skewness')

# Calories
qplot(y=temp$Calories,x="",geom='boxplot',fill=I('green'),ylab='Calories',main='Calories Skewness') 

# summary
summary(daily_data)