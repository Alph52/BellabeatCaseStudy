library(tidyverse)
library(lubridate)
# loading hourly data
hourly_data=read_csv("C:\\Users\\sasuk\\OneDrive\\Desktop\\DataAnalyticsCourse\\Project\\Fitbase_Data_Modified\\Hourly_Data_Merged\\hourly_merged.csv")


# boxplot
# Calories
qplot(x='',y=hourly_data$Calories,ylab='Calories',fill=I('blue'),geom='boxplot',main='Calories Skewness')

# Intensity
qplot(x='',y=hourly_data$`Total Intensity`,ylab='Intensity',fill=I('green'),geom='boxplot',main = 'Intensity Skewness')

# Steps
qplot(x='',y=hourly_data$StepTotal,ylab='Steps',fill=I('red'),geom='boxplot',main='Steps Skewness')

summary(hourly_data)